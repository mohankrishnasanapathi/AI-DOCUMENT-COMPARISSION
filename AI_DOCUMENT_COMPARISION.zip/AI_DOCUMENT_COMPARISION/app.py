"""
app.py
------
AI Document Comparison Assistant
Clean, minimal, professional end-to-end application for comparing two PDF documents.
Follows the official project brief:
- Minimalist, modern UI with white content cards and subtle purple accents.
- No developer dashboard or settings sidebar.
- Secure backend Gemini API configuration via python-dotenv.
- Two balanced upload cards (Original Document A & Revised Document B).
- Prominent "Compare Documents" button with real Gemini AI analysis.
- 7 dedicated results tabs: Summary A, Summary B, Similarities, Differences, Key Details, Conclusion, Limitations.
- Real downloadable DOCX comparison report.
- One-click "Start New Comparison" reset functionality.
"""

import hashlib
import os
import pandas as pd
import streamlit as st
from dotenv import load_dotenv

# Load environment configuration securely
load_dotenv()

from document_reader import (
    DocumentMetadata,
    extract_and_validate_pdf,
)
from comparison import (
    ComparisonResult,
    compare_documents_with_gemini,
)
from report_generator import generate_docx_report


# ==============================================================================
# Page Configuration & Clean Minimalist Styling
# ==============================================================================

st.set_page_config(
    page_title="AI Document Comparison Assistant",
    page_icon="📑",
    layout="wide",
    initial_sidebar_state="collapsed",
)

CUSTOM_CSS = """
<style>
    /* Hide the developer sidebar completely */
    [data-testid="stSidebar"] {
        display: none !important;
    }
    [data-testid="collapsedControl"] {
        display: none !important;
    }

    /* Overall page background and clean font */
    .stApp {
        background-color: #F8FAFC;
        color: #1E293B;
        font-family: -apple-system, BlinkMacSystemFont, "Segoe UI", Roboto, "Helvetica Neue", Arial, sans-serif;
    }

    /* Header styling */
    .main-header {
        text-align: center;
        padding: 1.5rem 0 1rem 0;
    }
    .main-title {
        font-size: 2.25rem;
        font-weight: 800;
        color: #0F172A;
        margin-bottom: 0.4rem;
        letter-spacing: -0.025em;
    }
    .main-subtitle {
        font-size: 1.05rem;
        color: #475569;
        max-width: 720px;
        margin: 0 auto 1.5rem auto;
        line-height: 1.5;
    }

    /* Workflow Stepper */
    .stepper-container {
        display: flex;
        justify-content: center;
        align-items: center;
        gap: 1.5rem;
        margin-bottom: 2rem;
        flex-wrap: wrap;
    }
    .step-chip {
        display: flex;
        align-items: center;
        gap: 0.5rem;
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        padding: 0.5rem 1rem;
        border-radius: 9999px;
        font-size: 0.9rem;
        font-weight: 600;
        color: #64748B;
        box-shadow: 0 1px 2px rgba(0,0,0,0.03);
    }
    .step-chip.active {
        background: #F5F3FF;
        border-color: #C4B5FD;
        color: #6D28D9;
    }
    .step-chip.completed {
        background: #F0FDF4;
        border-color: #BBF7D0;
        color: #16A34A;
    }
    .step-arrow {
        color: #94A3B8;
        font-weight: bold;
    }

    /* Clean White Content Cards */
    .card-container {
        background: #FFFFFF;
        border: 1px solid #E2E8F0;
        border-radius: 12px;
        padding: 1.5rem;
        box-shadow: 0 2px 4px rgba(0, 0, 0, 0.02);
        height: 100%;
    }
    .card-title {
        font-size: 1.15rem;
        font-weight: 700;
        color: #0F172A;
        margin-bottom: 0.75rem;
        display: flex;
        align-items: center;
        gap: 0.5rem;
    }

    /* Document Metric Chips */
    .metric-badge {
        display: inline-block;
        background-color: #F1F5F9;
        border: 1px solid #E2E8F0;
        border-radius: 6px;
        padding: 3px 8px;
        font-size: 0.8rem;
        font-weight: 600;
        color: #334155;
        margin-right: 6px;
        margin-bottom: 6px;
    }

    /* Differences Badges */
    .badge-added {
        background-color: #DCFCE7;
        color: #15803D;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.78rem;
        font-weight: 700;
    }
    .badge-removed {
        background-color: #FEE2E2;
        color: #B91C1C;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.78rem;
        font-weight: 700;
    }
    .badge-modified {
        background-color: #FEF3C7;
        color: #B45309;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.78rem;
        font-weight: 700;
    }
    .badge-conflict {
        background-color: #F3E8FF;
        color: #6D28D9;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.78rem;
        font-weight: 700;
    }
    .badge-uncertain {
        background-color: #F1F5F9;
        color: #475569;
        padding: 2px 8px;
        border-radius: 4px;
        font-size: 0.78rem;
        font-weight: 700;
    }

    /* Primary Button Style (Subtle Purple Accent) */
    div.stButton > button[kind="primary"] {
        background-color: #6D28D9 !important;
        border-color: #6D28D9 !important;
        color: #FFFFFF !important;
        font-weight: 600 !important;
        padding: 0.6rem 2rem !important;
        border-radius: 8px !important;
        transition: all 0.2s ease !important;
    }
    div.stButton > button[kind="primary"]:hover {
        background-color: #5B21B6 !important;
        border-color: #5B21B6 !important;
        box-shadow: 0 4px 6px -1px rgba(109, 40, 217, 0.2) !important;
    }

    /* Disclaimer Note */
    .scope-note {
        font-size: 0.85rem;
        color: #64748B;
        text-align: center;
        margin-top: 1rem;
        margin-bottom: 2rem;
    }
</style>
"""
st.markdown(CUSTOM_CSS, unsafe_allow_html=True)


# ==============================================================================
# Session State Initialization & Caching
# ==============================================================================

if "uploader_key" not in st.session_state:
    st.session_state.uploader_key = 0
if "doc_a_meta" not in st.session_state:
    st.session_state.doc_a_meta = None
if "doc_b_meta" not in st.session_state:
    st.session_state.doc_b_meta = None
if "file_a_hash" not in st.session_state:
    st.session_state.file_a_hash = None
if "file_b_hash" not in st.session_state:
    st.session_state.file_b_hash = None
if "comparison_result" not in st.session_state:
    st.session_state.comparison_result = None
if "comparison_error" not in st.session_state:
    st.session_state.comparison_error = None
if "comparison_cache" not in st.session_state:
    st.session_state.comparison_cache = {}
if "cached_report_bytes" not in st.session_state:
    st.session_state.cached_report_bytes = None
if "cached_report_key" not in st.session_state:
    st.session_state.cached_report_key = None
if "is_processing" not in st.session_state:
    st.session_state.is_processing = False


def reset_comparison():
    """Resets all uploaded files, extractions, and comparison results."""
    st.session_state.uploader_key += 1
    st.session_state.doc_a_meta = None
    st.session_state.doc_b_meta = None
    st.session_state.file_a_hash = None
    st.session_state.file_b_hash = None
    st.session_state.comparison_result = None
    st.session_state.comparison_error = None
    st.session_state.cached_report_bytes = None
    st.session_state.cached_report_key = None
    st.session_state.is_processing = False


# ==============================================================================
# Header & Workflow Stepper
# ==============================================================================

st.markdown(
    """
    <div class="main-header">
        <div class="main-title">AI Document Comparison Assistant</div>
        <div class="main-subtitle">
            Upload two PDF documents to discover similarities, differences, important changes, and key details using AI.
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)

# Determine active step for workflow stepper
meta_a: DocumentMetadata = st.session_state.doc_a_meta
meta_b: DocumentMetadata = st.session_state.doc_b_meta
comp: ComparisonResult = st.session_state.comparison_result

step1_cls = "completed" if (meta_a and meta_b and meta_a.is_valid and meta_b.is_valid) else "active"
step2_cls = "completed" if comp else ("active" if step1_cls == "completed" else "")
step3_cls = "active" if comp else ""

st.markdown(
    f"""
    <div class="stepper-container">
        <div class="step-chip {step1_cls}">
            <span>1</span> Upload Documents
        </div>
        <div class="step-arrow">➔</div>
        <div class="step-chip {step2_cls}">
            <span>2</span> Compare with AI
        </div>
        <div class="step-arrow">➔</div>
        <div class="step-chip {step3_cls}">
            <span>3</span> Review & Download Report
        </div>
    </div>
    """,
    unsafe_allow_html=True,
)


# ==============================================================================
# Backend Configuration Verification
# ==============================================================================

backend_api_key = os.getenv("GEMINI_API_KEY") or os.getenv("GOOGLE_API_KEY")
backend_model = os.getenv("GEMINI_MODEL", "gemini-flash-latest")

# If API key is missing from backend, display a friendly admin guidance notice
if not backend_api_key:
    st.warning(
        "⚠️ **Gemini API Key is not configured in the application environment.** "
        "Please ensure `GEMINI_API_KEY` is defined in your `.env` file before executing document comparisons.",
        icon="🔑",
    )


# ==============================================================================
# Document Upload Section (Balanced Side-by-Side Cards)
# ==============================================================================

col_left, col_right = st.columns(2, gap="large")

with col_left:
    st.markdown("### Document A — Original Document")
    uploaded_file_a = st.file_uploader(
        "Choose original PDF",
        type=["pdf"],
        key=f"file_a_{st.session_state.uploader_key}",
        help="Upload the baseline or earlier version of the document (PDF only).",
        label_visibility="collapsed",
    )

    if uploaded_file_a is not None:
        file_a_bytes = uploaded_file_a.getvalue()
        current_hash_a = hashlib.sha256(file_a_bytes).hexdigest()
        
        # Only re-extract if file content actually changed
        if st.session_state.file_a_hash != current_hash_a or st.session_state.doc_a_meta is None:
            st.session_state.doc_a_meta = extract_and_validate_pdf(
                uploaded_file_a, filename=uploaded_file_a.name
            )
            st.session_state.file_a_hash = current_hash_a
            # Invalidate stale comparison results
            st.session_state.comparison_result = None
            st.session_state.cached_report_bytes = None
            st.session_state.cached_report_key = None

    meta_a = st.session_state.doc_a_meta
    if meta_a:
        if not meta_a.is_valid:
            st.error(f"❌ {meta_a.error_message}")
        else:
            st.success(f"📄 **{meta_a.filename}**")
            st.markdown(
                f"""
                <div style="margin-bottom: 0.5rem;">
                    <span class="metric-badge">📦 Size: {meta_a.file_size_formatted}</span>
                    <span class="metric-badge">📄 Pages: {meta_a.total_pages}</span>
                    <span class="metric-badge">🔤 Characters: {meta_a.total_characters:,}</span>
                    <span class="metric-badge">📝 Words: {meta_a.total_words:,}</span>
                </div>
                """,
                unsafe_allow_html=True,
            )
            with st.expander("Preview Extracted Text", expanded=False):
                st.caption(meta_a.get_preview(max_chars=600))

            if meta_a.warnings:
                for w in meta_a.warnings:
                    st.warning(w, icon="⚠️")


with col_right:
    st.markdown("### Document B — Revised Document")
    uploaded_file_b = st.file_uploader(
        "Choose revised PDF",
        type=["pdf"],
        key=f"file_b_{st.session_state.uploader_key}",
        help="Upload the updated or modified version of the document (PDF only).",
        label_visibility="collapsed",
    )

    if uploaded_file_b is not None:
        file_b_bytes = uploaded_file_b.getvalue()
        current_hash_b = hashlib.sha256(file_b_bytes).hexdigest()

        # Only re-extract if file content actually changed
        if st.session_state.file_b_hash != current_hash_b or st.session_state.doc_b_meta is None:
            st.session_state.doc_b_meta = extract_and_validate_pdf(
                uploaded_file_b, filename=uploaded_file_b.name
            )
            st.session_state.file_b_hash = current_hash_b
            # Invalidate stale comparison results
            st.session_state.comparison_result = None
            st.session_state.cached_report_bytes = None
            st.session_state.cached_report_key = None

    meta_b = st.session_state.doc_b_meta
    if meta_b:
        if not meta_b.is_valid:
            st.error(f"❌ {meta_b.error_message}")
        else:
            st.success(f"📄 **{meta_b.filename}**")
            st.markdown(
                f"""
                <div style="margin-bottom: 0.5rem;">
                    <span class="metric-badge">📦 Size: {meta_b.file_size_formatted}</span>
                    <span class="metric-badge">📄 Pages: {meta_b.total_pages}</span>
                    <span class="metric-badge">🔤 Characters: {meta_b.total_characters:,}</span>
                    <span class="metric-badge">📝 Words: {meta_b.total_words:,}</span>
                </div>
                """,
                unsafe_allow_html=True,
            )
            with st.expander("Preview Extracted Text", expanded=False):
                st.caption(meta_b.get_preview(max_chars=600))

            if meta_b.warnings:
                for w in meta_b.warnings:
                    st.warning(w, icon="⚠️")


# Quick Sample Loader (convenient helper without developer settings)
sample_a_path = os.path.join("sample_documents", "document_a.pdf")
sample_b_path = os.path.join("sample_documents", "document_b.pdf")
if os.path.exists(sample_a_path) and os.path.exists(sample_b_path) and not meta_a and not meta_b:
    st.write("")
    _, col_sample, _ = st.columns([1, 2, 1])
    with col_sample:
        if st.button("📁 Load Sample Documents (Policy v1.2 & v2.0)", use_container_width=True):
            st.session_state.doc_a_meta = extract_and_validate_pdf(sample_a_path, "document_a.pdf (Policy v1.2)")
            st.session_state.doc_b_meta = extract_and_validate_pdf(sample_b_path, "document_b.pdf (Policy v2.0)")
            st.session_state.file_a_hash = st.session_state.doc_a_meta.content_hash
            st.session_state.file_b_hash = st.session_state.doc_b_meta.content_hash
            st.session_state.comparison_result = None
            st.session_state.cached_report_bytes = None
            st.session_state.cached_report_key = None
            st.rerun()


# ==============================================================================
# Main Compare Button & Multi-Stage Processing Flow
# ==============================================================================

st.write("")
is_ready = bool(
    meta_a
    and meta_b
    and meta_a.is_valid
    and meta_b.is_valid
    and backend_api_key
)

col_sp1, col_btn, col_sp2 = st.columns([1, 1.2, 1])
with col_btn:
    compare_button = st.button(
        "Compare Documents",
        type="primary",
        disabled=not is_ready or st.session_state.is_processing,
        use_container_width=True,
    )

if not meta_a or not meta_b:
    st.markdown(
        "<div style='text-align: center; color: #64748B; font-size: 0.9rem; margin-top: 0.25rem;'>"
        "Please upload both Document A and Document B to enable comparison."
        "</div>",
        unsafe_allow_html=True,
    )
elif meta_a and meta_b and (not meta_a.is_valid or not meta_b.is_valid):
    st.markdown(
        "<div style='text-align: center; color: #DC2626; font-size: 0.9rem; margin-top: 0.25rem;'>"
        "One or both files failed validation. Please resolve file issues above."
        "</div>",
        unsafe_allow_html=True,
    )


# Execution of Comparison with Progress Indicator and Cache
if compare_button and is_ready:
    st.session_state.is_processing = True
    st.session_state.comparison_error = None

    comparison_cache_key = f"{meta_a.content_hash}:{meta_b.content_hash}:{backend_model}"

    # Fast cache hit check
    if comparison_cache_key in st.session_state.comparison_cache:
        st.session_state.comparison_result = st.session_state.comparison_cache[comparison_cache_key]
        st.session_state.is_processing = False
        st.rerun()

    progress_placeholder = st.empty()
    status_text = st.empty()

    try:
        progress_placeholder.progress(20)
        status_text.caption("⏳ **Step 1/3:** Validating and formatting extracted text with page citations...")
        text_a = meta_a.get_page_text_with_markers()
        text_b = meta_b.get_page_text_with_markers()

        progress_placeholder.progress(50)
        status_text.caption("🧠 **Step 2/3:** Analyzing both documents with Gemini AI in a single structured request...")
        
        result = compare_documents_with_gemini(
            doc_a_filename=meta_a.filename,
            doc_a_text=text_a,
            doc_b_filename=meta_b.filename,
            doc_b_text=text_b,
            api_key=backend_api_key,
            model_name=backend_model,
            doc_a_hash=meta_a.content_hash,
            doc_b_hash=meta_b.content_hash,
        )

        progress_placeholder.progress(85)
        status_text.caption("📊 **Step 3/3:** Synthesizing comparison matrix and building executive report...")
        
        # Pre-generate and cache report bytes
        docx_buf = generate_docx_report(result, meta_a, meta_b)
        st.session_state.cached_report_bytes = docx_buf.getvalue()
        st.session_state.cached_report_key = comparison_cache_key

        progress_placeholder.progress(100)
        status_text.caption("✅ **Comparison Complete!**")

        st.session_state.comparison_cache[comparison_cache_key] = result
        st.session_state.comparison_result = result
        st.session_state.comparison_error = None

    except Exception as e:
        st.session_state.comparison_error = str(e)
        st.session_state.comparison_result = None
    finally:
        st.session_state.is_processing = False
        progress_placeholder.empty()
        status_text.empty()
        st.rerun()

if st.session_state.comparison_error:
    st.error(f"❌ Comparison Error: {st.session_state.comparison_error}")


# ==============================================================================
# Results Interface (Clean, Labelled Tabs)
# ==============================================================================

comp = st.session_state.comparison_result

if comp is not None:
    st.markdown("---")
    
    current_comp_key = f"{meta_a.content_hash}:{meta_b.content_hash}:{backend_model}"
    
    # Ensure cached report bytes are available without regenerating on tab switches
    if (
        st.session_state.cached_report_bytes is None
        or st.session_state.cached_report_key != current_comp_key
    ):
        st.session_state.cached_report_bytes = generate_docx_report(comp, meta_a, meta_b).getvalue()
        st.session_state.cached_report_key = current_comp_key

    # Header bar for results with Reset and Download actions
    res_header_col, action_col = st.columns([3, 2])
    with res_header_col:
        st.markdown(
            f"### Comparison Results\n"
            f"<span style='color: #64748B; font-size: 0.95rem;'>"
            f"Comparing **{comp.document_a_summary.filename}** (Original) with **{comp.document_b_summary.filename}** (Revised)"
            f"</span>",
            unsafe_allow_html=True,
        )

    with action_col:
        btn_c1, btn_c2 = st.columns([1.5, 1])
        with btn_c1:
            safe_name_a = comp.document_a_summary.filename.replace(" ", "_")[:12]
            safe_name_b = comp.document_b_summary.filename.replace(" ", "_")[:12]
            st.download_button(
                label="📥 Download Report (.docx)",
                data=st.session_state.cached_report_bytes,
                file_name=f"Comparison_Report_{safe_name_a}_vs_{safe_name_b}.docx",
                mime="application/vnd.openxmlformats-officedocument.wordprocessingml.document",
                type="primary",
                use_container_width=True,
                help="Download the completed Microsoft Word comparison report.",
            )
        with btn_c2:
            if st.button("Start New", use_container_width=True, help="Clear current comparison and reset"):
                reset_comparison()
                st.rerun()

    st.write("")

    # 7 Dedicated Tabs as specified in requirements
    tab_sum_a, tab_sum_b, tab_sim, tab_diff, tab_key_details, tab_conclusion, tab_limitations = st.tabs([
        "Summary A",
        "Summary B",
        "Similarities",
        "Differences",
        "Key Details",
        "Conclusion",
        "Limitations",
    ])

    # -------------------------------------------------------------------------
    # TAB 1: Summary A
    # -------------------------------------------------------------------------
    with tab_sum_a:
        st.markdown(f"#### Document A: {comp.document_a_summary.filename}")
        st.markdown("**Purpose & Overview:**")
        st.write(comp.document_a_summary.main_purpose)

        st.markdown("**Important Points:**")
        for pt in comp.document_a_summary.important_points:
            st.markdown(f"• {pt}")

        if comp.document_a_summary.key_requirements_and_conditions:
            st.markdown("**Main Requirements & Conditions:**")
            for req in comp.document_a_summary.key_requirements_and_conditions:
                st.markdown(f"• {req}")

    # -------------------------------------------------------------------------
    # TAB 2: Summary B
    # -------------------------------------------------------------------------
    with tab_sum_b:
        st.markdown(f"#### Document B: {comp.document_b_summary.filename}")
        st.markdown("**Purpose & Overview:**")
        st.write(comp.document_b_summary.main_purpose)

        st.markdown("**Important Points:**")
        for pt in comp.document_b_summary.important_points:
            st.markdown(f"• {pt}")

        if comp.document_b_summary.key_requirements_and_conditions:
            st.markdown("**Main Requirements & Conditions:**")
            for req in comp.document_b_summary.key_requirements_and_conditions:
                st.markdown(f"• {req}")

    # -------------------------------------------------------------------------
    # TAB 3: Similarities
    # -------------------------------------------------------------------------
    with tab_sim:
        st.markdown("#### Similarities & Common Provisions")
        st.caption("Statements, topics, requirements, and facts confirmed by both documents:")

        if not comp.similarities:
            st.info("No explicit shared provisions were identified between the uploaded documents.")
        else:
            for idx, item in enumerate(comp.similarities):
                with st.container():
                    st.markdown(f"**{idx + 1}. {item.topic}**")
                    st.write(item.description)
                    with st.expander("Supporting Evidence Excerpts", expanded=False):
                        st.markdown(f"• **Document A:** {item.evidence_doc_a}")
                        st.markdown(f"• **Document B:** {item.evidence_doc_b}")
                    st.markdown("<hr style='margin: 0.5rem 0;'>", unsafe_allow_html=True)

    # -------------------------------------------------------------------------
    # TAB 4: Differences
    # -------------------------------------------------------------------------
    with tab_diff:
        st.markdown("#### Meaningful Differences & Changes")
        st.caption("Added, removed, modified, or conflicting statements supported by textual evidence:")

        if not comp.differences:
            st.info("No significant differences were identified between the documents.")
        else:
            for diff in comp.differences:
                badge_class = {
                    "Added": "badge-added",
                    "Removed": "badge-removed",
                    "Modified": "badge-modified",
                    "Conflicting": "badge-conflict",
                    "Cannot Be Compared Reliably": "badge-uncertain",
                }.get(diff.category, "badge-uncertain")

                st.markdown(
                    f"""
                    <div style="margin-top: 0.75rem; margin-bottom: 0.25rem;">
                        <span class="{badge_class}">{diff.category.upper()}</span>
                        <strong style="margin-left: 8px; font-size: 1.05rem;">{diff.title}</strong>
                    </div>
                    """,
                    unsafe_allow_html=True,
                )
                st.write(diff.description)

                d_col1, d_col2 = st.columns(2)
                with d_col1:
                    st.markdown(f"**Document A:** {diff.doc_a_state}")
                    if diff.evidence_doc_a and diff.evidence_doc_a != "Not found":
                        st.caption(f"Citation: _{diff.evidence_doc_a}_")
                with d_col2:
                    st.markdown(f"**Document B:** {diff.doc_b_state}")
                    if diff.evidence_doc_b and diff.evidence_doc_b != "Not found":
                        st.caption(f"Citation: _{diff.evidence_doc_b}_")

                st.markdown("<hr style='margin: 0.5rem 0;'>", unsafe_allow_html=True)

    # -------------------------------------------------------------------------
    # TAB 5: Key Details
    # -------------------------------------------------------------------------
    with tab_key_details:
        st.markdown("#### Key Details Comparison Matrix")
        st.caption("Direct comparison of dates, numbers, amounts, stipends, eligibility, and rules:")

        if not comp.key_details:
            st.info("No specific verifiable key details were extracted.")
        else:
            table_rows = []
            for item in comp.key_details:
                table_rows.append({
                    "Detail": item.detail,
                    "Document A": item.document_a,
                    "Document B": item.document_b,
                    "Change or Observation": item.change_or_observation,
                    "Evidence": item.evidence,
                })
            df_details = pd.DataFrame(table_rows)

            st.dataframe(
                df_details,
                use_container_width=True,
                hide_index=True,
                column_config={
                    "Detail": st.column_config.TextColumn("Detail", width="medium"),
                    "Document A": st.column_config.TextColumn("Document A", width="medium"),
                    "Document B": st.column_config.TextColumn("Document B", width="medium"),
                    "Change or Observation": st.column_config.TextColumn("Change / Observation", width="large"),
                    "Evidence": st.column_config.TextColumn("Evidence", width="large"),
                },
            )

    # -------------------------------------------------------------------------
    # TAB 6: Conclusion
    # -------------------------------------------------------------------------
    with tab_conclusion:
        st.markdown("#### Overall Conclusion")
        st.markdown(
            f"""
            <div style="background-color: #FFFFFF; border-left: 4px solid #6D28D9; padding: 1.25rem; border-radius: 6px; font-size: 1.05rem; line-height: 1.6; border: 1px solid #E2E8F0; border-left-width: 4px;">
                {comp.overall_conclusion}
            </div>
            """,
            unsafe_allow_html=True,
        )

        st.write("")
        st.markdown("##### Change Overview")
        num_added = sum(1 for d in comp.differences if d.category == "Added")
        num_removed = sum(1 for d in comp.differences if d.category == "Removed")
        num_mod = sum(1 for d in comp.differences if d.category == "Modified")
        num_conf = sum(1 for d in comp.differences if d.category == "Conflicting")

        m1, m2, m3, m4, m5 = st.columns(5)
        m1.metric("Similarities", len(comp.similarities))
        m2.metric("Added Items", num_added)
        m3.metric("Modified Items", num_mod)
        m4.metric("Removed Items", num_removed)
        m5.metric("Conflicts", num_conf)

    # -------------------------------------------------------------------------
    # TAB 7: Limitations
    # -------------------------------------------------------------------------
    with tab_limitations:
        st.markdown("#### Processing Limitations & Notes")
        if comp.limitations:
            for lim in comp.limitations:
                st.info(f"• {lim}")
        else:
            st.success("No document truncation, unreadable pages, or processing limitations were identified.")

        st.markdown(
            f"<div class='scope-note'>{comp.legal_disclaimer}</div>",
            unsafe_allow_html=True,
        )


# Legal Notice Footer
st.markdown(
    """
    <div class="scope-note">
        Informational comparison assistant. This tool does not provide legal advice or verify statutory compliance.
    </div>
    """,
    unsafe_allow_html=True,
)
