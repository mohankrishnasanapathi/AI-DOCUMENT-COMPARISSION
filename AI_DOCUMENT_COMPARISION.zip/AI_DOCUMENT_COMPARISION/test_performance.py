"""
test_performance.py
-------------------
Benchmark and verify performance optimizations for the AI Document Comparison Assistant:
1. PDF extraction caching: First run vs subsequent runs (instant hash lookup).
2. AI comparison caching: Verifies stable composite hash cache prevents repeated Gemini calls.
3. DOCX report caching: Verifies completed comparison result is reused and report generation is cached.
4. Tab switching / Download simulation: Confirms no new AI requests occur.
"""

import io
import time
import unittest
from document_reader import extract_and_validate_pdf
from comparison import (
    ComparisonResult,
    get_sample_policy_comparison,
    compare_documents_with_gemini,
    _AI_COMPARISON_CACHE,
)
from report_generator import generate_docx_report, _REPORT_CACHE


class TestPerformanceOptimizations(unittest.TestCase):
    def setUp(self):
        self.doc_a_path = "sample_documents/document_a.pdf"
        self.doc_b_path = "sample_documents/document_b.pdf"

    def test_pdf_extraction_caching(self):
        """Verify second extraction of identical file is near-instantaneous (cache hit)."""
        # First extraction (parses bytes, reads pages, computes hash)
        t0 = time.perf_counter()
        meta_first = extract_and_validate_pdf(self.doc_a_path, "document_a.pdf")
        t_first = time.perf_counter() - t0

        # Second extraction (cached lookup via SHA-256)
        t1 = time.perf_counter()
        meta_second = extract_and_validate_pdf(self.doc_a_path, "document_a.pdf")
        t_second = time.perf_counter() - t1

        print(f"\n[PERF] PDF Extraction - 1st: {t_first*1000:.2f}ms | 2nd (Cached): {t_second*1000:.2f}ms")
        self.assertTrue(meta_first.is_valid)
        self.assertTrue(meta_second.is_valid)
        self.assertEqual(meta_first.content_hash, meta_second.content_hash)
        # Cached extraction should be faster than initial parse
        self.assertLessEqual(t_second, t_first + 0.005)

    def test_docx_report_generation_caching(self):
        """Verify that report generation is cached and reused without rebuilding docx tree."""
        comp = get_sample_policy_comparison()
        meta_a = extract_and_validate_pdf(self.doc_a_path, "document_a.pdf")
        meta_b = extract_and_validate_pdf(self.doc_b_path, "document_b.pdf")

        # First report generation
        t0 = time.perf_counter()
        buf_first = generate_docx_report(comp, meta_a, meta_b)
        t_first = time.perf_counter() - t0
        bytes_first = buf_first.getvalue()

        # Second report generation (cached)
        t1 = time.perf_counter()
        buf_second = generate_docx_report(comp, meta_a, meta_b)
        t_second = time.perf_counter() - t1
        bytes_second = buf_second.getvalue()

        print(f"[PERF] DOCX Report Build - 1st: {t_first*1000:.2f}ms | 2nd (Cached): {t_second*1000:.2f}ms")
        self.assertEqual(bytes_first, bytes_second)
        self.assertLess(t_second, t_first)
        self.assertLess(t_second, 0.01)  # Cached should be under 10ms

    def test_ai_comparison_caching(self):
        """Verify that comparison result cache prevents duplicate network requests for the same pair."""
        comp = get_sample_policy_comparison()
        hash_a = "mock_hash_a_123456"
        hash_b = "mock_hash_b_654321"
        model = "gemini-flash-latest"
        cache_key = f"{hash_a}:{hash_b}:{model}:v1"

        # Pre-seed cache as if previous comparison completed
        _AI_COMPARISON_CACHE[cache_key] = comp

        # Call compare_documents_with_gemini with matching hashes
        t0 = time.perf_counter()
        res = compare_documents_with_gemini(
            doc_a_filename="document_a.pdf",
            doc_a_text="Sample text A",
            doc_b_filename="document_b.pdf",
            doc_b_text="Sample text B",
            api_key="mock_key_not_called",
            model_name=model,
            doc_a_hash=hash_a,
            doc_b_hash=hash_b,
        )
        t_cached = time.perf_counter() - t0

        print(f"[PERF] Cached AI Result Lookup: {t_cached*1000:.3f}ms (Zero Network Overhead)")
        self.assertEqual(res.document_a_summary.filename, comp.document_a_summary.filename)
        self.assertLess(t_cached, 0.005)  # Less than 5 milliseconds!

    def test_tab_switching_zero_ai_call_simulation(self):
        """Verify that user navigating across 7 tabs generates zero new AI requests and zero docx rebuilds."""
        comp = get_sample_policy_comparison()
        meta_a = extract_and_validate_pdf(self.doc_a_path, "document_a.pdf")
        meta_b = extract_and_validate_pdf(self.doc_b_path, "document_b.pdf")

        # Generate report once
        cached_docx_bytes = generate_docx_report(comp, meta_a, meta_b).getvalue()
        
        initial_cache_size = len(_AI_COMPARISON_CACHE)

        # Simulate user clicking through all 7 tabs
        tabs = ["Summary A", "Summary B", "Similarities", "Differences", "Key Details", "Conclusion", "Limitations"]
        for tab in tabs:
            # Reusing already completed comp object and cached bytes
            self.assertIsNotNone(comp)
            self.assertIsNotNone(cached_docx_bytes)

        # Confirm no additional cache writes or API calls occurred
        self.assertEqual(len(_AI_COMPARISON_CACHE), initial_cache_size)


if __name__ == "__main__":
    unittest.main()
